// Gipfelstürmer leaderboard: best distance per player and stage, top 10 per stage.
// Storage: Upstash Redis over its REST API. Connect "Upstash for Redis" to the Vercel project;
// it sets KV_REST_API_URL / KV_REST_API_TOKEN (or UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN).
//
// GET  /api/leaderboard?stage=wiese                      -> { entries: [{ name, distance }] }
// POST /api/leaderboard { name, stage, distance }        -> same, after saving the score
//
// Each name appears once per stage (case-insensitive). A new score only replaces the old one if it is higher.

const STAGES = ['wiese', 'ebikon', 'reussbuehl', 'spa', 'alpnach', 'schuepfheim', 'fischbach', 'sursee', 'duenen', 'eis'];
const MAX_DISTANCE = 100000;

async function redis(commands) {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) throw new Error('missing-db');
  const r = await fetch(url.replace(/\/$/, '') + '/pipeline', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
    body: JSON.stringify(commands),
  });
  if (!r.ok) throw new Error('db-' + r.status);
  const out = await r.json();
  for (const item of out) if (item.error) throw new Error('db-' + item.error);
  return out.map(item => item.result);
}

// Names: trimmed, no control characters or angle brackets, at most 16 characters.
function cleanName(raw) {
  return String(raw == null ? '' : raw).replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16);
}

async function top10(stage) {
  const [flat] = await redis([['ZREVRANGE', 'lb:' + stage, 0, 9, 'WITHSCORES']]);
  const ids = [], scores = [];
  for (let i = 0; i < (flat || []).length; i += 2) { ids.push(flat[i]); scores.push(Number(flat[i + 1])); }
  if (!ids.length) return [];
  const [names] = await redis([['HMGET', 'lbnames:' + stage, ...ids]]);
  return ids.map((id, i) => ({ name: (names && names[i]) || id, distance: scores[i] }));
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    let body = {};
    if (req.method === 'POST') body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    else if (req.method !== 'GET') return res.status(405).json({ error: 'Nur GET und POST' });

    const stage = String(body.stage || (req.query && req.query.stage) || '');
    if (!STAGES.includes(stage)) return res.status(400).json({ error: 'Unbekannte Strecke' });

    if (req.method === 'POST') {
      const name = cleanName(body.name);
      const distance = Math.floor(Number(body.distance));
      if (!name) return res.status(400).json({ error: 'Name fehlt' });
      if (!Number.isFinite(distance) || distance < 1 || distance > MAX_DISTANCE) return res.status(400).json({ error: 'Ungültige Distanz' });
      const id = name.toLowerCase();
      await redis([
        ['ZADD', 'lb:' + stage, 'GT', distance, id],   // GT: only ever raise a player's score
        ['HSET', 'lbnames:' + stage, id, name],        // latest spelling of the name for display
      ]);
    }
    return res.status(200).json({ entries: await top10(stage) });
  } catch (e) {
    const missing = e && e.message === 'missing-db';
    return res.status(missing ? 503 : 500).json({ error: missing ? 'Datenbank nicht verbunden' : 'Serverfehler' });
  }
};

module.exports.cleanName = cleanName;
